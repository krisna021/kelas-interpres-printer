using System;

namespace InterfacePrinter
{
    interface IPrinterWindows
    {
        void Show();
        void Print();
    }
}